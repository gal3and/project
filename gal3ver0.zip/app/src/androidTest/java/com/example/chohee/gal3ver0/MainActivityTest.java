package com.example.chohee.gal3ver0;

import junit.framework.TestCase;

/**
 * Created by chohee on 2016-03-12.
 */
public class MainActivityTest extends TestCase {

}