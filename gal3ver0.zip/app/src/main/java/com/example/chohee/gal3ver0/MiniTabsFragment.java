package com.example.chohee.gal3ver0;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by chohee on 2016-03-12.
 */
public class MiniTabsFragment extends Fragment {

    private SlidingTabLayout mSlidingTabLayout;
    private ViewPager mViewPager;

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        mViewPager=(ViewPager) view.findViewById(R.id.viewpager);
        mViewPager.setAdapter(new MiniPagerAdapter());

        mSlidingTabLayout=(SlidingTabLayout) view.findViewById(R.id.sliding_tabs);
        mSlidingTabLayout.setViewPager(mViewPager);



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_mini_tabs, container, false);
    }

    class MiniPagerAdapter extends PagerAdapter{
        @Override
        public boolean isViewFromObject(View view, Object object) {
            return object==view;
        }

        @Override
        public int getCount() {
            return 6;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {

            View view =getActivity().getLayoutInflater().inflate(R.layout.pager_item,container,false);
            container.addView(view);
            TextView title = (TextView) view.findViewById(R.id.item_title);
            title.setText(String.valueOf(position+1));

            return view;
         }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public CharSequence getPageTitle(int position){
            return "Item "+(position+1);
        }
    }
}
